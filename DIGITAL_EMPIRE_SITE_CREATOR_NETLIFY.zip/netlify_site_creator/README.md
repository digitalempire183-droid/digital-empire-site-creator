# DIGITAL EMPIRE — Site Creator (Netlify)

Interface française permettant de publier un fichier HTML sur Netlify depuis l'application.

## Déploiement de l'outil sur Netlify

1. Décompresse l'archive.
2. Importe le contenu du dossier dans un dépôt GitHub.
3. Dans Netlify, sélectionne **Add new project → Import an existing project** et connecte le dépôt.
4. Dans **Project configuration → Environment variables**, ajoute :
   - `NETLIFY_AUTH_TOKEN` : un jeton personnel Netlify créé spécialement pour cet usage.
   - `DEPLOY_API_KEY` : une longue clé secrète aléatoire utilisée pour protéger le formulaire.
5. Déploie le projet sur Netlify. Si tu ajoutes ou modifies les variables après le premier déploiement, relance un déploiement.
6. Ouvre le site, indique un nom, sélectionne un fichier HTML et saisis la clé `DEPLOY_API_KEY`.

## Fonctionnement

- Le site web utilise une Netlify Function située dans `netlify/functions/deploy.js`.
- La fonction crée un nouveau site Netlify, puis lui envoie `index.html`.
- Le jeton Netlify reste côté serveur dans `NETLIFY_AUTH_TOKEN`.
- Le formulaire accepte un seul fichier HTML complet, limité à 1 Mo. Les images, fichiers CSS et scripts séparés ne sont pas téléversés.
- Chaque demande crée un nouveau site Netlify. Le nom doit être disponible sur Netlify.

## Sécurité

- Ne place jamais `NETLIFY_AUTH_TOKEN` dans `index.html`, dans le dépôt GitHub ou dans une archive partagée.
- Garde `DEPLOY_API_KEY` privée. Toute personne qui la connaît peut tenter d'utiliser la fonction de déploiement.
- Si un ancien jeton Netlify a déjà été exposé, révoque-le et crée-en un nouveau.
- Pour un service public, ajoute une authentification plus robuste, une limitation de débit et des journaux d'audit.

## Limites

Cette version reprend le fonctionnement du projet d'origine en remplaçant l'API Vercel par l'API Netlify. Elle publie uniquement un HTML autonome : elle ne reconstruit pas un projet multi-fichiers ou une application nécessitant une compilation.
