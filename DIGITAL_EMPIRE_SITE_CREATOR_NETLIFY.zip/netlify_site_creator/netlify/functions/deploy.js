// Netlify Function: creates a Netlify site and deploys a single index.html.
const crypto = require("crypto");
const MAX_HTML_BYTES = 1024 * 1024;

exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  };
  const reply = (statusCode, payload) => ({
    statusCode, headers, body: JSON.stringify(payload)
  });

  if (event.httpMethod !== "POST") {
    return { ...reply(405, { error: "Méthode non autorisée." }), headers: { ...headers, Allow: "POST" } };
  }

  const netlifyToken = process.env.NETLIFY_AUTH_TOKEN;
  const deployKey = process.env.DEPLOY_API_KEY;
  if (!netlifyToken || !deployKey) {
    return reply(500, { error: "Configuration serveur incomplète. Configure NETLIFY_AUTH_TOKEN et DEPLOY_API_KEY." });
  }

  const suppliedKey = event.headers?.["x-deploy-key"] || event.headers?.["X-Deploy-Key"];
  if (typeof suppliedKey !== "string" || suppliedKey.length !== deployKey.length ||
      !constantTimeEqual(suppliedKey, deployKey)) {
    return reply(401, { error: "Clé d’accès incorrecte." });
  }

  let body;
  try { body = JSON.parse(event.body || "{}"); }
  catch { return reply(400, { error: "Requête JSON invalide." }); }

  const name = typeof body.name === "string" ? body.name : "";
  const html = typeof body.html === "string" ? body.html : "";
  if (!/^[a-z0-9](?:[a-z0-9-]{0,48}[a-z0-9])?$/.test(name)) {
    return reply(400, { error: "Nom invalide. Utilise des minuscules, chiffres et tirets." });
  }
  const htmlBytes = Buffer.from(html, "utf8");
  if (!html || htmlBytes.length > MAX_HTML_BYTES) {
    return reply(400, { error: "Le HTML est vide ou dépasse la limite de 1 Mo." });
  }
  if (!/<html[\s>]/i.test(html) && !/<!doctype\s+html/i.test(html)) {
    return reply(400, { error: "Le contenu ne semble pas être une page HTML complète." });
  }

  const api = "https://api.netlify.com/api/v1";
  const apiFetch = async (path, options = {}) => {
    const response = await fetch(api + path, {
      ...options,
      headers: {
        Authorization: `Bearer ${netlifyToken}`,
        ...(options.headers || {})
      }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const message = data.message || data.error || `Netlify a retourné une erreur (${response.status}).`;
      throw new Error(String(message).slice(0, 220));
    }
    return data;
  };

  try {
    // Create a new Netlify site for each submitted HTML page.
    const site = await apiFetch("/sites", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name })
    });

    const sha = crypto.createHash("sha1").update(htmlBytes).digest("hex");
    const deploy = await apiFetch(`/sites/${encodeURIComponent(site.id)}/deploys`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ files: { "/index.html": sha } })
    });

    // Upload the file contents associated with the SHA-1 hash.
    const upload = await fetch(
      `${api}/deploys/${encodeURIComponent(deploy.id)}/files/index.html`,
      {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${netlifyToken}`,
          "Content-Type": "application/octet-stream"
        },
        body: htmlBytes
      }
    );
    if (!upload.ok) {
      const detail = await upload.text().catch(() => "");
      throw new Error(detail.slice(0, 180) || `Échec de l’envoi du fichier (${upload.status}).`);
    }

    return reply(200, {
      message: "Déploiement envoyé à Netlify. La publication peut prendre quelques instants.",
      url: site.ssl_url || site.url || (site.name ? `https://${site.name}.netlify.app` : null),
      siteId: site.id,
      deploymentId: deploy.id,
      readyState: deploy.state || "building"
    });
  } catch (error) {
    return reply(502, { error: error.message || "Impossible de joindre Netlify. Vérifie la configuration puis réessaie." });
  }
};

function constantTimeEqual(a, b) {
  return crypto.timingSafeEqual(Buffer.from(a, "utf8"), Buffer.from(b, "utf8"));
}
